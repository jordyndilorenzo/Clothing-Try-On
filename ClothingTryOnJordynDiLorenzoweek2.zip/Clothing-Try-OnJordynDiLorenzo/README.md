# Clothing-Try-On
Imagine a desktop app that lets users “try on” outfits using preset 2D images — a simplified version of an AR try-on experience. The program will feature a virtual mannequin or model that users can dress by selecting clothing pieces such as tops, bottoms, shoes, and accessories from a gallery. 
