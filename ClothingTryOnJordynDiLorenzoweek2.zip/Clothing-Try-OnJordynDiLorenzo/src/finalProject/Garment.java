

/**
* Lead Author(s): Jordyn DiLorenzo
* @author Jordiii; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-11-13
*/


package finalProject;
import javax.swing.ImageIcon;

/**
 * Purpose: The reponsibility of Garment is ...
 *
 * Garment is-a ...
 * Garment is ...
 */
public class Garment
{
	private String type;
    private String color;
    private String imagePath;

    public Garment(String type, String color, String imagePath) {
        this.type = type;
        this.color = color;
        this.imagePath = imagePath;
    }

    public String getType() {
        return type;
    }

    public String getColor() {
        return color;
    }

    public String getImagePath() {
        return imagePath;
    }

    public ImageIcon getImage() {
        return new ImageIcon(imagePath);
    }

    @Override
    public String toString() {
        return type + " (" + color + ")";
    }
}
