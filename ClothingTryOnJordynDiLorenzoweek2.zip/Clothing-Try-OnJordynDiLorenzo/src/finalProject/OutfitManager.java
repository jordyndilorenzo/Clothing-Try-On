/**
* Lead Author(s): Jordyn DiLorenzo
* @author Jordiii; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-11-13

*/



package finalProject;
import java.util.ArrayList;
import java.util.HashMap;
//import java.util.Random;
import java.io.*;

public class OutfitManager {
    private ArrayList<Garment> garments;
    private HashMap<String, Garment> currentOutfit;

    // Track current index for cycling
    private int topIndex = 0, bottomIndex = 0, shoesIndex = 0;
    private ArrayList<Garment> tops, bottoms, shoes;

    public OutfitManager() {
        garments = new ArrayList<>();
        currentOutfit = new HashMap<>();
        tops = new ArrayList<>();
        bottoms = new ArrayList<>();
        shoes = new ArrayList<>();
    }

    public void addGarment(Garment g) {
        garments.add(g);
        switch (g.getType().toLowerCase()) {
            case "top": tops.add(g); break;
            case "bottom": bottoms.add(g); break;
            case "shoes": shoes.add(g); break;
        }
    }

    public void nextTop() {
        if (!tops.isEmpty()) {
            topIndex = (topIndex + 1) % tops.size();
            currentOutfit.put("top", tops.get(topIndex));
        }
    }

    public void nextBottom() {
        if (!bottoms.isEmpty()) {
            bottomIndex = (bottomIndex + 1) % bottoms.size();
            currentOutfit.put("bottom", bottoms.get(bottomIndex));
        }
    }

    public void nextShoes() {
        if (!shoes.isEmpty()) {
            shoesIndex = (shoesIndex + 1) % shoes.size();
            currentOutfit.put("shoes", shoes.get(shoesIndex));
        }
    }

    public void randomizeOutfit() {
        java.util.Random rand = new java.util.Random();
        if (!tops.isEmpty()) currentOutfit.put("top", tops.get(rand.nextInt(tops.size())));
        if (!bottoms.isEmpty()) currentOutfit.put("bottom", bottoms.get(rand.nextInt(bottoms.size())));
        if (!shoes.isEmpty()) currentOutfit.put("shoes", shoes.get(rand.nextInt(shoes.size())));
    }

    public HashMap<String, Garment> getCurrentOutfit() {
        return currentOutfit;
    }

    public void saveOutfit(String filename) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (String key : currentOutfit.keySet()) {
                Garment g = currentOutfit.get(key);
                writer.println(key + "," + g.getType() + "," + g.getColor() + "," + g.getImagePath());
            }
        } catch (IOException e) {
            System.out.println("Error saving outfit: " + e.getMessage());
        }
    }

    public void loadOutfit(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    currentOutfit.put(parts[0], new Garment(parts[1], parts[2], parts[3]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading outfit: " + e.getMessage());
        }
    }
}