/**
* Lead Author(s): Jordyn DiLorenzo
* @author Jordiii; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-11-13
*/


package finalProject;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;

/**
 * Purpose: The reponsibility of BodyModel is ...
 *
 * BodyModel is-a ...
 * BodyModel is ...
 */
public class BodyModel extends JPanel 
{
	 private HashMap<String, Garment> outfit;

	    public BodyModel() {
	        outfit = new HashMap<>();
	    }

	    public void updateOutfit(HashMap<String, Garment> outfit) {
	        this.outfit = outfit;
	        repaint();
	    }

	    @Override
	    protected void paintComponent(Graphics g) {
	        super.paintComponent(g);

	        // Display garments in order: bottom, top, shoes
	        if (outfit.get("bottom") != null) {
	            g.drawImage(outfit.get("bottom").getImage().getImage(), 100, 100, null);
	        }
	        if (outfit.get("top") != null) {
	            g.drawImage(outfit.get("top").getImage().getImage(), 100, 50, null);
	        }
	        if (outfit.get("shoes") != null) {
	            g.drawImage(outfit.get("shoes").getImage().getImage(), 100, 200, null);
	        }
	    }
}
