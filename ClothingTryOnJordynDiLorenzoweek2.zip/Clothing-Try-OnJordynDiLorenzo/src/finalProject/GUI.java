
/**
* Lead Author(s):Jordyn DiLorenzo
* @author Jordiii; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-11-13
*/
package finalProject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.SwingUtilities;

public class GUI
{
	 private JFrame frame;
	    private BodyModel model;
	    private OutfitManager manager;

	    public GUI() {
	        manager = new OutfitManager();
	        model = new BodyModel();

	        // Example garments (replace with actual image paths)
	        manager.addGarment(new Garment("top", "red", "images/top1.png"));
	        manager.addGarment(new Garment("top", "green", "images/top2.png"));
	        manager.addGarment(new Garment("bottom", "blue", "images/bottom1.png"));
	        manager.addGarment(new Garment("bottom", "black", "images/bottom2.png"));
	        manager.addGarment(new Garment("shoes", "white", "images/shoes1.png"));
	        manager.addGarment(new Garment("shoes", "brown", "images/shoes2.png"));

	        frame = new JFrame("AR Fashion Try-On");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(600, 600);

	        JPanel buttonPanel = new JPanel();

	        JButton nextTopBtn = new JButton("Next Top");
	        JButton nextBottomBtn = new JButton("Next Bottom");
	        JButton nextShoesBtn = new JButton("Next Shoes");
	        JButton randomizeBtn = new JButton("Randomize Look");
	        JButton saveBtn = new JButton("Save Outfit");
	        JButton loadBtn = new JButton("Load Outfit");

	        nextTopBtn.addActionListener(e -> {
	            manager.nextTop();
	            model.updateOutfit(manager.getCurrentOutfit());
	        });

	        nextBottomBtn.addActionListener(e -> {
	            manager.nextBottom();
	            model.updateOutfit(manager.getCurrentOutfit());
	        });

	        nextShoesBtn.addActionListener(e -> {
	            manager.nextShoes();
	            model.updateOutfit(manager.getCurrentOutfit());
	        });

	        randomizeBtn.addActionListener(e -> {
	            manager.randomizeOutfit();
	            model.updateOutfit(manager.getCurrentOutfit());
	        });

	        saveBtn.addActionListener(e -> {
	            manager.saveOutfit("outfit.txt");
	        });

	        loadBtn.addActionListener(e -> {
	            manager.loadOutfit("outfit.txt");
	            model.updateOutfit(manager.getCurrentOutfit());
	        });

	        buttonPanel.add(nextTopBtn);
	        buttonPanel.add(nextBottomBtn);
	        buttonPanel.add(nextShoesBtn);
	        buttonPanel.add(randomizeBtn);
	        buttonPanel.add(saveBtn);
	        buttonPanel.add(loadBtn);

	        frame.setLayout(new BorderLayout());
	        frame.add(model, BorderLayout.CENTER);
	        frame.add(buttonPanel, BorderLayout.SOUTH);

	        frame.setVisible(true);

	        // Initialize first outfit
	        manager.randomizeOutfit();
	        model.updateOutfit(manager.getCurrentOutfit());
	    }

	    public static void main(String[] args) {
	        SwingUtilities.invokeLater(GUI::new);
	    }
}
